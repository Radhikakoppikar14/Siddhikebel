import React, { useState } from 'react';
import { SERVICES_DATA, ServiceItem } from '../data/siddhiData';
import { Check, ArrowRight, ZoomIn, X, Send, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ServicesSectionProps {
  onOpenRfq: (serviceName?: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onOpenRfq }) => {
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  // services whose photo failed to load: show a clean panel instead of a broken image icon
  const [broken, setBroken] = useState<Record<string, boolean>>({});

  return (
    <section id="services" className="py-10 sm:py-12 bg-white border-b border-[#F1D9CA] relative overflow-hidden">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-[#FFF1E8] rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-96 h-96 bg-[#D2430F]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.1 }}
            transition={{ duration: 0.55 }}
          >
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-widest uppercase text-[#5F524C] mb-2 px-3 py-1 rounded-full bg-[#FFF1E8] border border-[#F1D9CA]">
              <Sparkles className="w-3.5 h-3.5 text-[#D2430F]" />
              <span>Engineering Capabilities</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-normal text-[#231815] font-editorial tracking-tight">
              Services For Industries
            </h2>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.1 }}
            transition={{ duration: 0.55 }}
            className="text-sm sm:text-base text-[#5F524C] max-w-md font-light leading-relaxed"
          >
            Get benefited with our unique industrial solutions specially designed for Indian industries to enhance electrical performance and safety compliance.
          </motion.p>
        </div>

        {/* 4 Core Services */}
        <div className="space-y-12">
          {SERVICES_DATA.map((service, index) => {
            const isReversed = index % 2 !== 0;
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 35 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.1 }}
                transition={{ duration: 0.6, delay: index * 0.1, ease: [0.21, 0.47, 0.32, 0.98] }}
                whileHover={{ y: -6 }}
                className="bg-white rounded-3xl border border-[#F1D9CA] hover:border-[#F1D9CA] overflow-hidden shadow-xs hover:shadow-2xl transition-all duration-300"
              >
                <div
                  className={`grid grid-cols-1 lg:grid-cols-12 gap-8 items-center ${
                    isReversed ? 'lg:flex-row-reverse' : ''
                  }`}
                >
                  {/* Text Container */}
                  <div className={`p-8 lg:p-12 space-y-6 ${broken[service.id] ? 'lg:col-span-12' : isReversed ? 'lg:col-span-7 lg:order-2' : 'lg:col-span-7'}`}>
                    <div className="space-y-2">
                      <span className="inline-block text-xs font-semibold uppercase tracking-wider text-[#5F524C] px-2.5 py-1 rounded-md bg-[#FFF1E8] border border-[#F1D9CA]">
                        {service.subtitle}
                      </span>
                      <h3 className="text-2xl sm:text-3xl font-normal text-[#231815] font-editorial leading-tight">
                        {service.title}
                      </h3>
                    </div>

                    <p className="text-sm sm:text-base text-[#231815]/85 font-light leading-relaxed">
                      {service.description}
                    </p>

                    {/* Features list */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      {service.features.map((feat, fIdx) => (
                        <motion.div
                          key={fIdx}
                          whileHover={{ x: 4 }}
                          className="flex items-start gap-2.5 text-xs text-[#231815] p-2 rounded-lg hover:bg-[#FFFAF6] transition-colors"
                        >
                          <div className="mt-0.5 p-0.5 bg-[#F1D9CA]/50 text-[#5F524C] rounded-full shrink-0">
                            <Check className="w-3.5 h-3.5 text-[#5F524C]" />
                          </div>
                          <span>{feat}</span>
                        </motion.div>
                      ))}
                    </div>

                    <div className="pt-4 flex flex-wrap items-center gap-4">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => onOpenRfq(service.title)}
                        className="inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider text-[#FFFAF6] bg-[#D2430F] hover:bg-[#A8340A] rounded-xl transition-all shadow-sm cursor-pointer"
                      >
                        <span>Inquire for {service.subtitle}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </motion.button>

                      {!broken[service.id] && (
                      <button
                        onClick={() => setSelectedService(service)}
                        className="inline-flex items-center gap-1.5 px-4 py-3 text-xs font-medium text-[#231815] hover:text-[#5F524C] bg-[#FFFAF6] hover:bg-[#D2430F]/8 rounded-xl border border-[#F1D9CA] transition-colors cursor-pointer"
                      >
                        <ZoomIn className="w-3.5 h-3.5 text-[#5F524C]" />
                        <span>View Work Photo</span>
                      </button>
                      )}
                    </div>
                  </div>

                  {/* Image Container */}
                  <div
                    onClick={() => { if (!broken[service.id]) setSelectedService(service); }}
                    className={`h-72 sm:h-88 lg:h-full min-h-[340px] relative overflow-hidden group ${broken[service.id] ? 'hidden' : 'cursor-zoom-in'} ${
                      isReversed ? 'lg:col-span-5 lg:order-1' : 'lg:col-span-5'
                    }`}
                  >
                    {!broken[service.id] && (
                    <motion.img
                      whileHover={{ scale: 1.08 }}
                      transition={{ duration: 0.6, ease: 'easeOut' }}
                      src={service.image}
                      alt={service.title}
                      onError={() => setBroken((b) => ({ ...b, [service.id]: true }))}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#FFFAF6]/60 via-transparent to-transparent pointer-events-none" />

                    <div className="absolute bottom-4 right-4 px-3 py-1 rounded-full bg-[#FFFAF6]/95 backdrop-blur-xs text-[11px] font-medium text-[#231815] flex items-center gap-1.5 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity border border-[#F1D9CA]">
                      <ZoomIn className="w-3 h-3 text-[#5F524C]" />
                      <span>Click to Enlarge</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Service Image Lightbox Modal */}
      <AnimatePresence>
        {selectedService && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedService(null)}
            className="fixed inset-0 z-50 bg-[#FFF1E8] backdrop-blur-sm backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-4xl w-full max-h-[calc(100dvh-2rem)] sm:max-h-[calc(100dvh-3rem)] flex flex-col bg-[#FFFAF6] rounded-3xl overflow-hidden shadow-2xl border border-[#F1D9CA]"
            >
              <div className="relative bg-[#FFF1E8] flex-1 min-h-0 flex items-center justify-center overflow-hidden">
                <img
                  src={selectedService.image}
                  alt={selectedService.title}
                  className="max-h-[48dvh] sm:max-h-[52dvh] w-full object-contain"
                />
                <button
                  onClick={() => setSelectedService(null)}
                  className="absolute top-4 right-4 p-2.5 rounded-full bg-white/80 hover:bg-white text-[#231815] transition-colors cursor-pointer"
                  aria-label="Close image popup"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="shrink-0 overflow-y-auto p-4 sm:p-6 space-y-2 sm:space-y-3 bg-[#FFFAF6]">
                <div className="flex items-center gap-2 text-xs font-semibold text-[#5F524C] uppercase tracking-wider">
                  <span className="px-2 py-0.5 rounded bg-[#FFF1E8] border border-[#F1D9CA]">{selectedService.subtitle}</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-normal text-[#231815] font-editorial">
                  {selectedService.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#5F524C] font-light leading-relaxed">
                  {selectedService.description}
                </p>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#F1D9CA]">
                  <span className="text-xs text-[#D2430F] font-light">
                    Factory trained engineers &amp; certified testing equipment.
                  </span>
                  <button
                    onClick={() => {
                      const title = selectedService.title;
                      setSelectedService(null);
                      onOpenRfq(title);
                    }}
                    className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#D2430F] hover:bg-[#A8340A] text-[#FFFAF6] text-xs font-semibold uppercase tracking-wider transition-all shadow-sm cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Inquire About This Service</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};